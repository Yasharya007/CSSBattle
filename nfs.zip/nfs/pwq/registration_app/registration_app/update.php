<?php
$conn = new mysqli("localhost", "root", "", "registration_app");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = $_GET['id'];
$result = $conn->query("SELECT * FROM registrations WHERE id = $id");

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
} else {
    die("Record not found!");
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Registration</title>
</head>
<body>
    <h2>Edit Registration</h2>
    <form action="update_process.php" method="POST">
        <input type="hidden" name="id" value="<?php echo $row['id']; ?>">

        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required><br><br>

        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($row['phone']); ?>"><br><br>

        <label for="address">Address:</label>
        <textarea id="address" name="address"><?php echo htmlspecialchars($row['address']); ?></textarea><br><br>

        <button type="submit">Update</button>
    </form>
</body>
</html>
