function displayDate() {
  const currentDate = new Date();
  document.getElementById("dateBox").value = currentDate.toLocaleString();
}

function calculateFactorial() {
  let n = prompt("Enter a number to calculate its factorial:");
  n = parseInt(n);

  if (isNaN(n) || n < 0) {
    alert("Please enter a valid non-negative integer.");
    return;
  }

  let factorial = 1;
  for (let i = 1; i <= n; i++) {
    factorial *= i;
  }

  alert(`The factorial of ${n} is ${factorial}`);
}

function generateMultiplicationTable() {
  let n = prompt("Enter a number to generate its multiplication table:");
  n = parseInt(n);

  if (isNaN(n)) {
    alert("Please enter a valid number.");
    return;
  }

  let table = "";
  for (let i = 1; i <= 10; i++) {
    table += `${n} x ${i} = ${n * i}\n`;
  }

  alert(`Multiplication table for ${n}:\n\n${table}`);
}

function calculateSum() {
  let n = prompt("Enter a number:");
  n = parseInt(n);

  if (isNaN(n)) {
    alert("Please enter a valid number.");
    return;
  }

  let sum = 0;
  for (let i = 1; i <= n; i++) {
    let confirmNumber = confirm(`Include ${i} in the sum?`);
    if (confirmNumber) {
      sum += i;
    }
  }

  alert(`The sum of selected numbers is ${sum}`);
}

function quickSort(arr) {
  if (arr.length <= 1) {
    return arr;
  }

  const pivot = arr[arr.length - 1];
  const left = [];
  const right = [];

  for (let i = 0; i < arr.length - 1; i++) {
    if (arr[i] < pivot) {
      left.push(arr[i]);
    } else {
      right.push(arr[i]);
    }
  }

  return [...quickSort(left), pivot, ...quickSort(right)];
}

function quickSortExample() {
  const array = [34, 7, 23, 32, 5, 62];
  alert(`Original Array: ${array.join(", ")}`);

  const sortedArray = quickSort(array);
  alert(`Sorted Array: ${sortedArray.join(", ")}`);
}

function checkOddEven() {
  let output = "";

  for (let i = 0; i <= 15; i++) {
    if (i % 2 === 0) {
      output += `${i} is even\n`;
    } else {
      output += `${i} is odd\n`;
    }
  }

  alert(output);
}
