<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "web_portal";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}



$name = $_POST['name'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

$query = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";
if (mysqli_query($conn, $query)) {
    header('Location: login.html');
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}
?>
