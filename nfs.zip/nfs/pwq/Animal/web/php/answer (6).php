<!DOCTYPE html>
<html>
<head>
    <title>Age Calculation</title>
</head>
<body>
    <form method="post">
        <input type="date" name="birthdate" required>
        <button type="submit">Calculate Age</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $birthdate = new DateTime($_POST['birthdate']);
        $today = new DateTime();
        $age = $today->diff($birthdate);
        echo "Current Age: " . $age->y . " years, " . $age->m . " months, " . $age->d . " days.";
    }
    ?>
</body>
</html>
