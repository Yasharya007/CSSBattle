<?php
session_start();
if (!isset($_SESSION['count'])) {
    $_SESSION['count'] = 0;
}
$_SESSION['count'] += 1;
echo "<h1>Number of Visitors: " . $_SESSION['count'] . "</h1>";
?>
