<?php
$matrix1 = [[1, 2], [3, 4]];
$matrix2 = [[5, 6], [7, 8]];
$result = [];

for ($i = 0; $i < 2; $i++) {
    for ($j = 0; $j < 2; $j++) {
        $result[$i][$j] = 0;
        for ($k = 0; $k < 2; $k++) {
            $result[$i][$j] += $matrix1[$i][$k] * $matrix2[$k][$j];
        }
    }
}

echo "Result of Matrix Multiplication:<br>";
foreach ($result as $row) {
    echo implode(' ', $row) . "<br>";
}
?>
