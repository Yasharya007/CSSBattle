<?php
$matrix1 = [[1, 2], [3, 4]];
$matrix2 = [[5, 6], [7, 8]];
$result = [];

for ($i = 0; $i < 2; $i++) {
    for ($j = 0; $j < 2; $j++) {
        $result[$i][$j] = $matrix1[$i][$j] + $matrix2[$i][$j];
    }
}

echo "Result of Matrix Addition:<br>";
foreach ($result as $row) {
    echo implode(' ', $row) . "<br>";
}
?>
