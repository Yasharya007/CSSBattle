<!DOCTYPE html>
<html>
<head>
    <title>Simple Calculator</title>
</head>
<body>
    <form method="post">
        <input type="number" name="num1" required>
        <input type="number" name="num2" required>
        <select name="operation">
            <option value="add">Add</option>
            <option value="sub">Subtract</option>
            <option value="mul">Multiply</option>
            <option value="div">Divide</option>
        </select>
        <button type="submit">Calculate</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];
        $operation = $_POST['operation'];
        switch ($operation) {
            case 'add':
                echo "Result: " . ($num1 + $num2);
                break;
            case 'sub':
                echo "Result: " . ($num1 - $num2);
                break;
            case 'mul':
                echo "Result: " . ($num1 * $num2);
                break;
            case 'div':
                echo "Result: " . ($num1 / $num2);
                break;
        }
    }
    ?>
</body>
</html>
