<!DOCTYPE html>
<html>
<head>
    <title>Digital Clock</title>
    <script>
        function updateTime() {
            const time = new Date();
            document.getElementById("clock").innerHTML = time.toLocaleTimeString();
        }
        setInterval(updateTime, 1000);
    </script>
</head>
<body>
    <h1>Current Server Time: <span id="clock"></span></h1>
</body>
</html>
