<!DOCTYPE html>
<html>
<head>
    <title>Image Switch</title>
</head>
<body>
    <form method="post">
        <select name="image">
            <option value="1">Image 1</option>
            <option value="2">Image 2</option>
            <option value="3">Image 3</option>
        </select>
        <button type="submit">Show Image</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $image = $_POST['image'];
        switch ($image) {
            case '1':
                echo "<img src='image1.jpg' alt='Image 1'>";
                break;
            case '2':
                echo "<img src='image2.jpg' alt='Image 2'>";
                break;
            case '3':
                echo "<img src='image3.jpg' alt='Image 3'>";
                break;
        }
    }
    ?>
</body>
</html>
