<!DOCTYPE html>
<html>
<head>
    <title>String Case Conversion</title>
</head>
<body>
    <form method="post">
        <input type="text" name="inputString" required>
        <button type="submit">Convert</button>
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $inputString = $_POST['inputString'];
        echo "Lowercase: " . strtolower($inputString) . "<br>";
        echo "Uppercase: " . strtoupper($inputString) . "<br>";
        echo "Capitalized: " . ucwords($inputString) . "<br>";
    }
    ?>
</body>
</html>
