const mode=document.querySelector("#mode>img");
const main=document.querySelector("main");
console.dir(mode);
let flage=1;
mode.addEventListener("click",(e)=>{
if(flage==1){
    console.dir(mode.src="./sunny.png");
    flage=0;
    main.style=`background-color:gray`
}
else if(flage==0)
{
    console.dir(mode.src="./moon.png");
    flage=1;
     main.style=`background-color:white`
}
})