<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link rel="stylesheet" href="register.css">
</head>
<body>
	<div class = 'containor' >
		<h2>Register</h2>
    <form id="registrationForm" action="connection.php" method="post">
        <label for="fullName">Full Name:</label>
        <input type="text" id="fullname" name="fullname">
   
        <br>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email">

        <br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password">
   
        <br>

       

        <button type="submit" value="submit">Register</button>
    </form>


	</div>
        
</body>
</html>
