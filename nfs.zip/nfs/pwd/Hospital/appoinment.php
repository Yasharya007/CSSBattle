<?php
$conn = new mysqli("localhost", "root", "", "hospital_management");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$patient_id = $_POST['patient_id'];
$date = $_POST['date'];
$time = $_POST['time'];

$stmt = $conn->prepare("INSERT INTO appointments (patient_id, date, time) VALUES (?, ?, ?)");
$stmt->bind_param("iss", $patient_id, $date, $time);
$success = $stmt->execute();

if ($success) {
    echo "<script>alert('Appointment booked successfully!'); window.location.href='index.php';</script>";
} else {
    echo "<script>alert('Failed to book appointment.'); window.location.href='index.php';</script>";
}

$stmt->close();
$conn->close();
?>
