<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management Portal</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Library Management Portal</h1>
    <div id="book-list">
        <h2>Available Books</h2>
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'php/connection.php'; // Database connection
                $query = "SELECT * FROM books";
                $result = mysqli_query($conn, $query);

                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                        <td>{$row['title']}</td>
                        <td>{$row['author']}</td>
                        <td>" . ($row['is_available'] ? "Available" : "Not Available") . "</td>
                        <td>";
                    if ($row['is_available']) {
                        echo "<form action='php/borrow.php' method='POST'>
                            <input type='hidden' name='book_id' value='{$row['book_id']}'>
                            <input type='text' name='borrower_name' placeholder='Your Name' required>
                            <button type='submit'>Borrow</button>
                            </form>";
                    } else {
                        echo "N/A";
                    }
                    echo "</td>
                    </tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
