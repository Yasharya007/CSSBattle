<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $book_id = $_POST['book_id'];
    $borrower_name = $_POST['borrower_name'];
    $borrow_date = date('Y-m-d');

    // Check availability
    $check_query = "SELECT is_available FROM books WHERE book_id = $book_id";
    $check_result = mysqli_query($conn, $check_query);
    $book = mysqli_fetch_assoc($check_result);

    if ($book['is_available']) {
        // Update availability in books table
        $update_query = "UPDATE books SET is_available = 0 WHERE book_id = $book_id";
        mysqli_query($conn, $update_query);

        // Insert into borrowed_books table
        $insert_query = "INSERT INTO borrowed_books (book_id, borrower_name, borrow_date) 
                         VALUES ($book_id, '$borrower_name', '$borrow_date')";
        mysqli_query($conn, $insert_query);

        echo "Book borrowed successfully!";
    } else {
        echo "Book is not available.";
    }
}

header('Location: ../index.php');
?>
