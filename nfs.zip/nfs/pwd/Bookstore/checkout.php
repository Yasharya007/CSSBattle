<?php
$conn = new mysqli("localhost", "root", "", "bookstore");
if ($conn->connect_error) die(json_encode(["success" => false]));

$input = file_get_contents("php://input");
$order = json_decode($input, true);

$total = array_reduce($order, function ($sum, $item) {
    return $sum + $item['price'];
}, 0);

$items = json_encode($order);
$stmt = $conn->prepare("INSERT INTO orders (items, total) VALUES (?, ?)");
$stmt->bind_param("sd", $items, $total);
$success = $stmt->execute();

echo json_encode(["success" => $success]);
$stmt->close();
$conn->close();
?>
