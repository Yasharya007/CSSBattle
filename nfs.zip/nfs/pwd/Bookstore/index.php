<?php
$conn = new mysqli("localhost", "root", "", "bookstore");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch books
$result = $conn->query("SELECT * FROM books");
$books = [];
while ($row = $result->fetch_assoc()) $books[] = $row;

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookstore Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Bookstore Management</h1>
    <div id="books">
        <?php foreach ($books as $book): ?>
        <div class="book-item">
            <h3><?= $book['title'] ?></h3>
            <p>Author: <?= $book['author'] ?></p>
            <p>Price: ₹<?= $book['price'] ?></p>
            <button onclick="addToCart(<?= $book['id'] ?>, '<?= $book['title'] ?>', <?= $book['price'] ?>)">Add to Cart</button>
        </div>
        <?php endforeach; ?>
    </div>
    <div id="cart">
        <h2>Cart</h2>
        <ul id="cart-items"></ul>
        <p>Total: ₹<span id="cart-total">0</span></p>
        <button id="checkout-btn" onclick="checkout()">Checkout</button>
    </div>
    <script src="script.js"></script>
</body>
</html>
