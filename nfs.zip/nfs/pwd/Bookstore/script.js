let cart = [];

function addToCart(id, title, price) {
    cart.push({ id, title, price });
    updateCart();
}

function updateCart() {
    const cartItems = document.getElementById("cart-items");
    const cartTotal = document.getElementById("cart-total");
    cartItems.innerHTML = "";
    let total = 0;
    cart.forEach((item, index) => {
        cartItems.innerHTML += `<li>${item.title} - ₹${item.price} <button onclick="removeFromCart(${index})">Remove</button></li>`;
        total += item.price;
    });
    cartTotal.innerText = total.toFixed(2);
}

function removeFromCart(index) {
    cart.splice(index, 1);
    updateCart();
}

function checkout() {
    if (cart.length === 0) {
        alert("Cart is empty!");
        return;
    }
    fetch("checkout.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(cart),
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert("Order placed successfully!");
            cart = [];
            updateCart();
        } else {
            alert("Error placing order!");
        }
    });
}
