<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $event_id = $_POST['event_id'];

    $sql = "INSERT INTO registrations (name, email, event_id) VALUES ('$name', '$email', $event_id)";
    if ($conn->query($sql) === TRUE) {
        $conn->query("UPDATE events SET seats_available = seats_available - 1 WHERE id = $event_id");
        echo "Registration successful!";
    } else {
        echo "Error: " . $conn->error;
    }
    $conn->close();
}
?>
