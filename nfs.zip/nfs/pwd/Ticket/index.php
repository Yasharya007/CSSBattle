<?php
$conn = new mysqli("localhost", "root", "", "ticket_booking");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch events
$result = $conn->query("SELECT * FROM events");
$events = [];
while ($row = $result->fetch_assoc()) $events[] = $row;

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket Booking System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Ticket Booking System</h1>
    <div id="events">
        <h2>Available Events</h2>
        <?php if (count($events) > 0): ?>
        <table border="1">
            <tr>
                <th>ID</th>
                <th>Event Name</th>
                <th>Date</th>
                <th>Time</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
            <?php foreach ($events as $event): ?>
            <tr>
                <td><?= $event['id'] ?></td>
                <td><?= $event['name'] ?></td>
                <td><?= $event['date'] ?></td>
                <td><?= $event['time'] ?></td>
                <td>₹<?= $event['price'] ?></td>
                <td>
                    <button onclick="bookTicket(<?= $event['id'] ?>, '<?= $event['name'] ?>', <?= $event['price'] ?>)">Book Ticket</button>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php else: ?>
        <p>No events available.</p>
        <?php endif; ?>
    </div>
    <div id="booking-form">
        <h2>Book Ticket</h2>
        <form id="booking" method="POST" action="booking.php">
            <input type="hidden" name="event_id" id="event_id">
            <label for="event_name">Event Name:</label>
            <input type="text" id="event_name" name="event_name" readonly>
            <label for="customer_name">Your Name:</label>
            <input type="text" id="customer_name" name="customer_name" required>
            <label for="tickets">Number of Tickets:</label>
            <input type="number" id="tickets" name="tickets" min="1" required>
            <button type="submit">Submit</button>
        </form>
    </div>
    <script>
        function bookTicket(eventId, eventName, price) {
            document.getElementById('event_id').value = eventId;
            document.getElementById('event_name').value = eventName;
        }
    </script>
</body>
</html>
