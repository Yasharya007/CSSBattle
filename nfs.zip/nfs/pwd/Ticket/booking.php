<?php
$conn = new mysqli("localhost", "root", "", "ticket_booking");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$event_id = $_POST['event_id'];
$customer_name = $_POST['customer_name'];
$tickets = $_POST['tickets'];

// Fetch event price
$result = $conn->query("SELECT price FROM events WHERE id=$event_id");
$event = $result->fetch_assoc();
$total_price = $tickets * $event['price'];

// Insert booking
$stmt = $conn->prepare("INSERT INTO bookings (event_id, customer_name, tickets, total_price) VALUES (?, ?, ?, ?)");
$stmt->bind_param("isid", $event_id, $customer_name, $tickets, $total_price);
$success = $stmt->execute();

if ($success) {
    echo "<script>alert('Ticket booked successfully!'); window.location.href='index.php';</script>";
} else {
    echo "<script>alert('Failed to book ticket.'); window.location.href='index.php';</script>";
}

$stmt->close();
$conn->close();
?>
