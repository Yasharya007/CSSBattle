<?php
$conn = new mysqli("localhost", "root", "", "food_ordering");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Fetch menu items
$result = $conn->query("SELECT * FROM menu");
$menu = [];
while ($row = $result->fetch_assoc()) $menu[] = $row;

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Ordering System</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Food Ordering System</h1>
    <div id="menu">
        <?php foreach ($menu as $item): ?>
        <div class="menu-item">
            <h3><?= $item['name'] ?></h3>
            <p>Price: ₹<?= $item['price'] ?></p>
            <button onclick="addToCart(<?= $item['id'] ?>, '<?= $item['name'] ?>', <?= $item['price'] ?>)">Add to Cart</button>
        </div>
        <?php endforeach; ?>
    </div>
    <div id="cart">
        <h2>Cart</h2>
        <ul id="cart-items"></ul>
        <p>Total: ₹<span id="cart-total">0</span></p>
        <button id="checkout-btn" onclick="checkout()">Checkout</button>
    </div>
    <script src="script.js"></script>
</body>
</html>
