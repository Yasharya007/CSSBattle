<?php
$conn = new mysqli("localhost", "root", "", "course_review_system");

// Fetch courses
$courses = $conn->query("SELECT * FROM courses");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data for review submission
    $course_id = (int)$_POST['course_id'];
    $username = $conn->real_escape_string($_POST['username']);
    $rating = (int)$_POST['rating'];
    $review_text = $conn->real_escape_string($_POST['review_text']);

    // Insert the review into the database
    $sql = "INSERT INTO reviews (course_id, username, rating, review_text) 
            VALUES ($course_id, '$username', $rating, '$review_text')";
    if ($conn->query($sql)) {
        echo "Review submitted successfully!";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Review System</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .course { margin-bottom: 20px; border: 1px solid #ccc; padding: 10px; }
        .review-form { margin-top: 20px; }
        .review { margin-top: 10px; padding: 5px; background: #f9f9f9; }
        .rating { font-size: 20px; }
    </style>
</head>
<body>
    <h1>Courses</h1>

    <?php while ($course = $courses->fetch_assoc()): ?>
        <div class="course">
            <h2><?php echo htmlspecialchars($course['title']); ?></h2>
            <p><?php echo htmlspecialchars($course['description']); ?></p>

            <!-- Display average rating for the course -->
            <?php
            $course_id = $course['id'];
            $reviews = $conn->query("SELECT * FROM reviews WHERE course_id = $course_id");
            $total_rating = 0;
            $review_count = $reviews->num_rows;

            while ($review = $reviews->fetch_assoc()) {
                $total_rating += $review['rating'];
            }

            $average_rating = $review_count > 0 ? $total_rating / $review_count : 0;
            echo "<p>Average Rating: " . round($average_rating, 2) . " / 5 (" . $review_count . " reviews)</p>";
            ?>

            <h3>Reviews</h3>
            <div class="reviews">
                <?php
                $reviews->data_seek(0);
                while ($review = $reviews->fetch_assoc()): ?>
                    <div class="review">
                        <p><strong><?php echo htmlspecialchars($review['username']); ?></strong></p>
                        <p>Rating: <?php echo $review['rating']; ?>/5</p>
                        <p><?php echo nl2br(htmlspecialchars($review['review_text'])); ?></p>
                    </div>
                <?php endwhile; ?>
            </div>

            <!-- Review submission form -->
            <div class="review-form">
                <h3>Submit Your Review</h3>
                <form method="POST">
                    <input type="hidden" name="course_id" value="<?php echo $course_id; ?>">
                    <label for="username">Your Name:</label><br>
                    <input type="text" name="username" required><br><br>
                    <label for="rating">Rating:</label><br>
                    <select name="rating" required>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                    </select><br><br>
                    <label for="review_text">Review:</label><br>
                    <textarea name="review_text" rows="4" cols="50" required></textarea><br><br>
                    <button type="submit">Submit Review</button>
                </form>
            </div>
        </div>
    <?php endwhile; ?>

</body>
</html>

<?php
$conn->close();
?>
