<?php
$conn = new mysqli("localhost", "root", "", "course_review_system");

// Fetch all courses
$courses = $conn->query("SELECT * FROM courses");

// Handle adding new course
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $conn->real_escape_string($_POST['title']);
    $description = $conn->real_escape_string($_POST['description']);

    $sql = "INSERT INTO courses (title, description) VALUES ('$title', '$description')";
    if ($conn->query($sql)) {
        echo "Course added successfully! <a href='admin_dashboard.php'>Refresh</a>";
    } else {
        echo "Error: " . $conn->error;
    }
}

// Handle course deletion
if (isset($_GET['delete'])) {
    $course_id = (int)$_GET['delete'];
    $conn->query("DELETE FROM courses WHERE id = $course_id");
    header('Location: admin_dashboard.php');  // Redirect after deletion
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
</head>
<body>
    <h1>Admin Dashboard</h1>

    <h2>Add New Course</h2>
    <form method="POST">
        <label for="title">Course Title:</label><br>
        <input type="text" name="title" required><br><br>
        <label for="description">Course Description:</label><br>
        <textarea name="description" rows="4" cols="50" required></textarea><br><br>
        <button type="submit">Add Course</button>
    </form>

    <h2>Existing Courses</h2>
    <table border="1">
        <tr>
            <th>Course ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
        <?php while ($course = $courses->fetch_assoc()): ?>
            <tr>
                <td><?php echo $course['id']; ?></td>
                <td><?php echo htmlspecialchars($course['title']); ?></td>
                <td><?php echo htmlspecialchars($course['description']); ?></td>
                <td>
                    <a href="?delete=<?php echo $course['id']; ?>" onclick="return confirm('Are you sure you want to delete this course?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>
