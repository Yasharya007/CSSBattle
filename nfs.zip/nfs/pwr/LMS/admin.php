<?php
$conn = new mysqli("localhost", "root", "", "library_management");

// Add a new book
if (isset($_POST['add'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $author = $conn->real_escape_string($_POST['author']);
    $copies = (int)$_POST['copies'];

    $sql = "INSERT INTO books (title, author, copies_available) VALUES ('$title', '$author', '$copies')";
    $conn->query($sql);
}

// Update an existing book
if (isset($_POST['update'])) {
    $id = (int)$_POST['id'];
    $title = $conn->real_escape_string($_POST['title']);
    $author = $conn->real_escape_string($_POST['author']);
    $copies = (int)$_POST['copies'];

    $sql = "UPDATE books SET title='$title', author='$author', copies_available='$copies' WHERE id=$id";
    $conn->query($sql);
}

// Delete a book
if (isset($_POST['delete'])) {
    $id = (int)$_POST['id'];
    $sql = "DELETE FROM books WHERE id=$id";
    $conn->query($sql);
}

// Fetch all books
$books = $conn->query("SELECT * FROM books");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        form { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        table, th, td { border: 1px solid #ddd; padding: 10px; }
        th { background-color: #f4f4f4; }
        .btn { padding: 5px 10px; background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:disabled { background-color: #ccc; }
    </style>
</head>
<body>
    <h1>Admin Panel</h1>

    <form method="POST">
        <h3>Add Book</h3>
        <input type="text" name="title" placeholder="Title" required>
        <input type="text" name="author" placeholder="Author" required>
        <input type="number" name="copies" placeholder="Copies Available" required>
        <button type="submit" name="add" class="btn">Add Book</button>
    </form>

    <form method="POST">
        <h3>Update/Delete Book</h3>
        <select name="id" required>
            <option value="">Select a Book</option>
            <?php while ($book = $books->fetch_assoc()): ?>
                <option value="<?php echo $book['id']; ?>">
                    <?php echo htmlspecialchars($book['title']); ?>
                </option>
            <?php endwhile; ?>
        </select>
        <input type="text" name="title" placeholder="New Title" required>
        <input type="text" name="author" placeholder="New Author" required>
        <input type="number" name="copies" placeholder="New Copies Available" required>
        <button type="submit" name="update" class="btn">Update</button>
        <button type="submit" name="delete" class="btn" style="background-color: #FF4136;">Delete</button>
    </form>

    <a href="index.php" style="text-decoration: none; background: #007BFF; color: white; padding: 10px; border-radius: 5px;">Back to Home</a>
</body>
</html>
