<?php
$conn = new mysqli("localhost", "root", "", "library_management");

// Fetch all books
$books = $conn->query("SELECT * FROM books WHERE copies_available > 0");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Library Management System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        .books { margin-bottom: 20px; }
        .book { margin: 10px 0; }
        .borrow-form { margin-top: 20px; }
        .btn { padding: 10px 15px; background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:disabled { background-color: #ccc; }
    </style>
</head>
<body>
    <h1>Library Management System</h1>

    <div class="books">
        <h2>Available Books</h2>
        <ul>
            <?php while ($book = $books->fetch_assoc()): ?>
                <li>
                    <strong><?php echo htmlspecialchars($book['title']); ?></strong> by <?php echo htmlspecialchars($book['author']); ?>
                    (Copies: <?php echo htmlspecialchars($book['copies_available']); ?>)
                </li>
            <?php endwhile; ?>
        </ul>
    </div>

    <div class="borrow-form">
        <h2>Borrow Books</h2>
        <form action="borrow.php" method="POST">
            <label for="name">Name:</label><br>
            <input type="text" id="name" name="name" required><br><br>

            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required><br><br>

            <label for="books">Select Books:</label><br>
            <select id="books" name="books[]" multiple required>
                <?php
                $books->data_seek(0);
                while ($book = $books->fetch_assoc()) {
                    echo "<option value='{$book['id']}'>{$book['title']} by {$book['author']}</option>";
                }
                ?>
            </select><br><br>

            <button type="submit" class="btn">Borrow</button>
        </form>
    </div>

    <a href="admin.php" style="text-decoration: none; background: #007BFF; color: white; padding: 10px; border-radius: 5px;">Go to Admin Panel</a>
</body>
</html>
