<?php
$conn = new mysqli("localhost", "root", "", "library_management");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $book_ids = $_POST['books'];

    if (!empty($name) && !empty($email) && !empty($book_ids)) {
        $book_ids_str = implode(",", $book_ids);

        // Insert borrower details
        $sql = "INSERT INTO borrowers (user_name, email, book_ids) VALUES ('$name', '$email', '$book_ids_str')";
        if ($conn->query($sql)) {
            foreach ($book_ids as $book_id) {
                $conn->query("UPDATE books SET copies_available = copies_available - 1 WHERE id = $book_id");
            }
            echo "Books borrowed successfully! <a href='index.php'>Go back</a>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "All fields are required!";
    }
}
$conn->close();
?>
