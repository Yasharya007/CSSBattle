<?php
session_start();  // Start the session

// Initialize the cart if not already done
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Check if an item ID is provided in the POST request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve the item ID from the POST data
    $item_id = $_POST['item_id'];

    // Check if the item is already in the cart, and add it if not
    if (!in_array($item_id, $_SESSION['cart'])) {
        $_SESSION['cart'][] = $item_id;  // Add item ID to cart (session)
    }

    // Redirect back to the main page to show updated cart
    header("Location: index.php");
    exit;
}
?>
