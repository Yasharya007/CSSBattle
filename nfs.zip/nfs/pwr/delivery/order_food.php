<?php
$conn = new mysqli('localhost', 'root', '', 'check');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_name = $_POST['user_name'];
    $delivery_address = $_POST['delivery_address'];
    $item_id = $_POST['item_id'];
    $quantity = $_POST['quantity'];
    $order_type = $_POST['order_type'];

    $stmt = $conn->prepare("INSERT INTO orders (user_name, item_id, quantity, delivery_address, order_type) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("siiss", $user_name, $item_id, $quantity, $delivery_address, $order_type);
    $stmt->execute();

    echo "Food ordered successfully!";
}

$conn->close();
?>
