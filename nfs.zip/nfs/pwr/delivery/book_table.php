<?php
$conn = new mysqli('localhost', 'root', '', 'check');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_name = $_POST['user_name'];
    $date_time = $_POST['date_time'];
    $number_of_people = $_POST['number_of_people'];

    $stmt = $conn->prepare("INSERT INTO bookings (user_name, date_time, number_of_people) VALUES (?, ?, ?)");
    $stmt->bind_param("ssi", $user_name, $date_time, $number_of_people);
    $stmt->execute();

    echo "Table booked!";
}

$conn->close();
?>
