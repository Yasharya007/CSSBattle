<?php
session_start();  // Start the session to track the cart

// Connect to the database
$conn = new mysqli('localhost', 'root', '', 'check');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch food items from the database
$result = $conn->query("SELECT * FROM items");

// Check if query was successful
if (!$result) {
    die("Query failed: " . $conn->error);
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Management System</title>
</head>
<body>
    <h1>Welcome to Food Management System</h1>
    
    <h2>Food Items</h2>
    <?php
    // Check if any items were fetched
    if ($result->num_rows > 0) {
        // Display each food item
        while ($row = $result->fetch_assoc()) {
            echo "<div>";
            echo "<h3>" . $row['name'] . " - $" . $row['price'] . "</h3>";
            echo "<p>" . $row['description'] . "</p>";
            // Form to add item to the cart
            echo "<form method='POST' action='cart.php'>
                    <input type='hidden' name='item_id' value='" . $row['id'] . "'>
                    <button type='submit'>Add to Cart</button>
                  </form>";
            echo "</div>";
        }
    } else {
        echo "<p>No food items available.</p>";
    }
    ?>
    
    <h2>Your Cart</h2>
    <?php
    // Check if the cart has items
    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        $cart_item_ids = implode(",", $_SESSION['cart']);  // Convert cart items array to a string
        $result = $conn->query("SELECT * FROM items WHERE id IN ($cart_item_ids)");

        echo "<ul>";
        while ($row = $result->fetch_assoc()) {
            echo "<li>" . $row['name'] . " - $" . $row['price'] . "</li>";
        }
        echo "</ul>";

        // Button to proceed to checkout
        echo "<a href='checkout.php'><button>Proceed to Checkout</button></a>";
    } else {
        echo "<p>Your cart is empty.</p>";
    }
    ?>

    <h2>Book a Table</h2>
    <form method="POST" action="book_table.php">
        <input type="text" name="user_name" placeholder="Your Name" required><br>
        <input type="datetime-local" name="date_time" required><br>
        <input type="number" name="number_of_people" min="1" required><br>
        <button type="submit">Book Table</button>
    </form>

    <h2>Order Delivery</h2>
    <form method="POST" action="order_food.php">
        <input type="text" name="user_name" placeholder="Your Name" required><br>
        <input type="text" name="delivery_address" placeholder="Delivery Address" required><br>
        <input type="number" name="item_id" placeholder="Item ID" required><br>
        <input type="number" name="quantity" min="1" required><br>
        <select name="order_type">
            <option value="delivery">Delivery</option>
            <option value="pickup">Pickup</option>
        </select><br>
        <button type="submit">Order Food</button>
    </form>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
