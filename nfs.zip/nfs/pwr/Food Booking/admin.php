<?php
$conn = new mysqli("localhost", "root", "", "food_booking_system");

// Add a new food item
if (isset($_POST['add'])) {
    $name = $conn->real_escape_string($_POST['name']);
    $description = $conn->real_escape_string($_POST['description']);
    $price = (float)$_POST['price'];
    $quantity = (int)$_POST['quantity'];

    $sql = "INSERT INTO food_items (name, description, price, available_quantity) VALUES ('$name', '$description', $price, $quantity)";
    $conn->query($sql);
}

// Update or delete a food item
if (isset($_POST['update']) || isset($_POST['delete'])) {
    $id = (int)$_POST['id'];
    if (isset($_POST['update'])) {
        $name = $conn->real_escape_string($_POST['name']);
        $description = $conn->real_escape_string($_POST['description']);
        $price = (float)$_POST['price'];
        $quantity = (int)$_POST['quantity'];

        $sql = "UPDATE food_items SET name='$name', description='$description', price=$price, available_quantity=$quantity WHERE id=$id";
        $conn->query($sql);
    } elseif (isset($_POST['delete'])) {
        $sql = "DELETE FROM food_items WHERE id=$id";
        $conn->query($sql);
    }
}

// Fetch all food items and orders
$food_items = $conn->query("SELECT * FROM food_items");
$orders = $conn->query("SELECT o.*, f.name AS food_name FROM orders o JOIN food_items f ON o.food_item_id = f.id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        form { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        table, th, td { border: 1px solid #ddd; padding: 10px; }
        th { background-color: #f4f4f4; }
        .btn { padding: 5px 10px; background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:disabled { background-color: #ccc; }
    </style>
</head>
<body>
    <h1>Admin Panel</h1>

    <form method="POST">
        <h3>Add Food Item</h3>
        <input type="text" name="name" placeholder="Food Name" required>
        <textarea name="description" placeholder="Description" required></textarea>
        <input type="number" name="price" placeholder="Price" required step="0.01">
        <input type="number" name="quantity" placeholder="Available Quantity" required>
        <button type="submit" name="add" class="btn">Add Food Item</button>
    </form>

    <form method="POST">
        <h3>Update/Delete Food Item</h3>
        <select name="id" required>
            <option value="">Select a Food Item</option>
            <?php while ($food_item = $food_items->fetch_assoc()): ?>
                <option value="<?php echo $food_item['id']; ?>"><?php echo htmlspecialchars($food_item['name']); ?></option>
            <?php endwhile; ?>
        </select>
        <input type="text" name="name" placeholder="New Food Name">
        <textarea name="description" placeholder="New Description"></textarea>
        <input type="number" name="price" placeholder="New Price" step="0.01">
        <input type="number" name="quantity" placeholder="New Available Quantity">
        <button type="submit" name="update" class="btn">Update Food Item</button>
        <button type="submit" name="delete" class="btn">Delete Food Item</button>
    </form>

    <h3>Orders</h3>
    <table>
        <tr>
            <th>User Name</th>
            <th>Email</th>
            <th>Food Item</th>
            <th>Quantity</th>
            <th>Order Date</th>
        </tr>
        <?php while ($order = $orders->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($order['user_name']); ?></td>
                <td><?php echo htmlspecialchars($order['email']); ?></td>
                <td><?php echo htmlspecialchars($order['food_name']); ?></td>
                <td><?php echo htmlspecialchars($order['quantity']); ?></td>
                <td><?php echo htmlspecialchars($order['order_date']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

</body>
</html>
