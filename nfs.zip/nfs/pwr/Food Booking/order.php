<?php
$conn = new mysqli("localhost", "root", "", "food_booking_system");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $food_item_id = (int)$_POST['food_item'];
    $quantity = (int)$_POST['quantity'];

    // Fetch the selected food item details
    $food_item = $conn->query("SELECT * FROM food_items WHERE id = $food_item_id")->fetch_assoc();

    if ($food_item && $quantity > 0 && $quantity <= $food_item['available_quantity']) {
        // Insert order details
        $sql = "INSERT INTO orders (user_name, email, food_item_id, quantity) 
                VALUES ('$name', '$email', $food_item_id, $quantity)";
        if ($conn->query($sql)) {
            // Update available quantity
            $conn->query("UPDATE food_items SET available_quantity = available_quantity - $quantity WHERE id = $food_item_id");
            echo "Order placed successfully! <a href='index.php'>Go back</a>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Invalid quantity selection. <a href='index.php'>Go back</a>";
    }
}
$conn->close();
?>
