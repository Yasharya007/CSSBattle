<?php
$conn = new mysqli("localhost", "root", "", "food_booking_system");

// Fetch all food items
$food_items = $conn->query("SELECT * FROM food_items WHERE available_quantity > 0");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Order Booking System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        .food-items { margin-bottom: 20px; }
        .food-item { margin: 10px 0; }
        .order-form { margin-top: 20px; }
        .btn { padding: 10px 15px; background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:disabled { background-color: #ccc; }
    </style>
</head>
<body>
    <h1>Food Order Booking System</h1>

    <div class="food-items">
        <h2>Available Food Items</h2>
        <ul>
            <?php while ($food_item = $food_items->fetch_assoc()): ?>
                <li class="food-item">
                    <strong><?php echo htmlspecialchars($food_item['name']); ?></strong> - 
                    <?php echo htmlspecialchars($food_item['description']); ?> <br>
                    Price: $<?php echo htmlspecialchars($food_item['price']); ?> | 
                    Available Quantity: <?php echo htmlspecialchars($food_item['available_quantity']); ?>
                </li>
            <?php endwhile; ?>
        </ul>
    </div>

    <div class="order-form">
        <h2>Place Order</h2>
        <form action="order.php" method="POST">
            <label for="name">Name:</label><br>
            <input type="text" id="name" name="name" required><br><br>

            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required><br><br>

            <label for="food_item">Select Food Item:</label><br>
            <select id="food_item" name="food_item" required>
                <?php
                $food_items->data_seek(0); 
                while ($food_item = $food_items->fetch_assoc()) {
                    echo "<option value='{$food_item['id']}'>{$food_item['name']} (Price: \$" . 
                         htmlspecialchars($food_item['price']) . ")</option>";
                }
                ?>
            </select><br><br>

            <label for="quantity">Quantity:</label><br>
            <input type="number" id="quantity" name="quantity" min="1" required><br><br>

            <button type="submit" class="btn">Place Order</button>
        </form>
    </div>

    <a href="admin.php" style="text-decoration: none; background: #007BFF; color: white; padding: 10px; border-radius: 5px;">Go to Admin Panel</a>
</body>
</html>
