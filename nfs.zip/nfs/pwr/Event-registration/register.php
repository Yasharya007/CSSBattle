<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "event_registration");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate and process form inputs
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $event_ids = $_POST['events'];

    if (!empty($name) && !empty($email) && !empty($event_ids)) {
        $event_ids_str = implode(",", $event_ids);

        // Insert into registrations table
        $sql = "INSERT INTO registrations (user_name, email, event_ids) VALUES ('$name', '$email', '$event_ids_str')";
        if ($conn->query($sql)) {
            // Update seat availability
            foreach ($event_ids as $event_id) {
                $conn->query("UPDATE events SET seats_available = seats_available - 1 WHERE id = $event_id");
            }
            echo "Registration successful! <a href='index.php'>Go back</a>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "All fields are required!";
    }
}

$conn->close();
?>
