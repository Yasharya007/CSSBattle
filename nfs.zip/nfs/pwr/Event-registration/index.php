<?php
// Connect to the database
$conn = new mysqli("localhost", "root", "", "event_registration");

// Fetch events
$sql = "SELECT * FROM events WHERE seats_available > 0 ORDER BY event_date ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Registration</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        .events { margin-bottom: 20px; }
        .event { margin: 10px 0; }
        .register-form { margin-top: 20px; }
        .calendar { display: flex; flex-wrap: wrap; gap: 10px; }
        .calendar-item { border: 1px solid #ddd; padding: 10px; width: 200px; border-radius: 5px; }
        .btn { padding: 10px 15px; background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:disabled { background-color: #ccc; }
    </style>
</head>
<body>

    <h1>Event Registration System</h1>

    <div class="events">
        <h2>Available Events</h2>
        <div class="calendar">
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="calendar-item">
                        <strong><?php echo htmlspecialchars($row['event_name']); ?></strong><br>
                        Date: <?php echo htmlspecialchars($row['event_date']); ?><br>
                        Seats: <?php echo htmlspecialchars($row['seats_available']); ?><br>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <p>No events available.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="register-form">
        <h2>Register for Events</h2>
        <form action="register.php" method="POST">
            <label for="name">Name:</label><br>
            <input type="text" id="name" name="name" required><br><br>

            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required><br><br>

            <label for="events">Select Events:</label><br>
            <select id="events" name="events[]" multiple required>
                <?php
                $result->data_seek(0); // Reset result pointer
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='{$row['id']}'>{$row['event_name']} ({$row['event_date']})</option>";
                }
                ?>
            </select><br><br>

            <button type="submit" class="btn">Register</button>
        </form>
    </div>

</body>
</html>
