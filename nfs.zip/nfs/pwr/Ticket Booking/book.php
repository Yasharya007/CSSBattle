<?php
$conn = new mysqli("localhost", "root", "", "movie_booking_system");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $movie_id = (int)$_POST['movie'];
    $seats = (int)$_POST['seats'];

    // Fetch the selected movie's available seats
    $movie = $conn->query("SELECT * FROM movies WHERE id = $movie_id")->fetch_assoc();

    if ($movie && $seats > 0 && $seats <= $movie['available_seats']) {
        // Insert booking details
        $sql = "INSERT INTO bookings (user_name, email, movie_id, seats) 
                VALUES ('$name', '$email', $movie_id, $seats)";
        if ($conn->query($sql)) {
            // Update available seats
            $conn->query("UPDATE movies SET available_seats = available_seats - $seats WHERE id = $movie_id");
            echo "Booking successful! <a href='index.php'>Go back</a>";
        } else {
            echo "Error: " . $conn->error;
        }
    } else {
        echo "Invalid seat selection. <a href='index.php'>Go back</a>";
    }
}
$conn->close();
?>
