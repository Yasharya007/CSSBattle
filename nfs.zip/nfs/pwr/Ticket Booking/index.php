<?php
$conn = new mysqli("localhost", "root", "", "movie_booking_system");

// Fetch all movies
$movies = $conn->query("SELECT * FROM movies WHERE available_seats > 0");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Movie Ticket Booking System</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        .movies { margin-bottom: 20px; }
        .movie { margin: 10px 0; }
        .booking-form { margin-top: 20px; }
        .btn { padding: 10px 15px; background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:disabled { background-color: #ccc; }
    </style>
</head>
<body>
    <h1>Movie Ticket Booking System</h1>

    <div class="movies">
        <h2>Available Movies</h2>
        <ul>
            <?php while ($movie = $movies->fetch_assoc()): ?>
                <li>
                    <strong><?php echo htmlspecialchars($movie['title']); ?></strong> 
                    (Showtime: <?php echo htmlspecialchars(date("d M Y, h:i A", strtotime($movie['showtime']))); ?>, 
                    Seats: <?php echo htmlspecialchars($movie['available_seats']); ?>)
                </li>
            <?php endwhile; ?>
        </ul>
    </div>

    <div class="booking-form">
        <h2>Book Tickets</h2>
        <form action="book.php" method="POST">
            <label for="name">Name:</label><br>
            <input type="text" id="name" name="name" required><br><br>

            <label for="email">Email:</label><br>
            <input type="email" id="email" name="email" required><br><br>

            <label for="movie">Select Movie:</label><br>
            <select id="movie" name="movie" required>
                <?php
                $movies->data_seek(0);
                while ($movie = $movies->fetch_assoc()) {
                    echo "<option value='{$movie['id']}'>{$movie['title']} (Showtime: " . 
                         htmlspecialchars(date("d M Y, h:i A", strtotime($movie['showtime']))) . ")</option>";
                }
                ?>
            </select><br><br>

            <label for="seats">Number of Seats:</label><br>
            <input type="number" id="seats" name="seats" min="1" required><br><br>

            <button type="submit" class="btn">Book Now</button>
        </form>
    </div>

    <a href="admin.php" style="text-decoration: none; background: #007BFF; color: white; padding: 10px; border-radius: 5px;">Go to Admin Panel</a>
</body>
</html>
