<?php
$conn = new mysqli("localhost", "root", "", "movie_booking_system");

// Add a new movie
if (isset($_POST['add'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $showtime = $conn->real_escape_string($_POST['showtime']);
    $seats = (int)$_POST['seats'];

    $sql = "INSERT INTO movies (title, showtime, available_seats) VALUES ('$title', '$showtime', $seats)";
    $conn->query($sql);
}

// Update or delete a movie
if (isset($_POST['update']) || isset($_POST['delete'])) {
    $id = (int)$_POST['id'];
    if (isset($_POST['update'])) {
        $title = $conn->real_escape_string($_POST['title']);
        $showtime = $conn->real_escape_string($_POST['showtime']);
        $seats = (int)$_POST['seats'];

        $sql = "UPDATE movies SET title='$title', showtime='$showtime', available_seats='$seats' WHERE id=$id";
        $conn->query($sql);
    } elseif (isset($_POST['delete'])) {
        $sql = "DELETE FROM movies WHERE id=$id";
        $conn->query($sql);
    }
}

// Fetch all movies and bookings
$movies = $conn->query("SELECT * FROM movies");
$bookings = $conn->query("SELECT b.*, m.title AS movie_title FROM bookings b JOIN movies m ON b.movie_id = m.id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { text-align: center; }
        form { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        table, th, td { border: 1px solid #ddd; padding: 10px; }
        th { background-color: #f4f4f4; }
        .btn { padding: 5px 10px; background-color: #007BFF; color: white; border: none; border-radius: 5px; cursor: pointer; }
        .btn:disabled { background-color: #ccc; }
    </style>
</head>
<body>
    <h1>Admin Panel</h1>

    <form method="POST">
        <h3>Add Movie</h3>
        <input type="text" name="title" placeholder="Movie Title" required>
        <input type="datetime-local" name="showtime" required>
        <input type="number" name="seats" placeholder="Available Seats" required>
        <button type="submit" name="add" class="btn">Add Movie</button>
    </form>

    <form method="POST">
        <h3>Update/Delete Movie</h3>
        <select name="id" required>
            <option value="">Select a Movie</option>
            <?php while ($movie = $movies->fetch_assoc()): ?>
                <option value="<?php echo $movie['id']; ?>"><?php echo htmlspecialchars($movie['title']); ?></option>
            <?php endwhile; ?>
        </select>
        <input type="text" name="title" placeholder="New Title" required>
        <input type="datetime-local" name="showtime" required>
        <input type="number" name="seats" placeholder="New Available Seats" required>
        <button type="submit" name="update" class="btn">Update</button>
        <button type="submit" name="delete" class="btn" style="background-color: #FF4136;">Delete</button>
    </form>

    <h2>Booking History</h2>
    <table>
        <tr>
            <th>User Name</th>
            <th>Email</th>
            <th>Movie</th>
            <th>Seats</th>
            <th>Booking Date</th>
        </tr>
        <?php while ($booking = $bookings->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($booking['user_name']); ?></td>
                <td><?php echo htmlspecialchars($booking['email']); ?></td>
                <td><?php echo htmlspecialchars($booking['movie_title']); ?></td>
                <td><?php echo htmlspecialchars($booking['seats']); ?></td>
                <td><?php echo htmlspecialchars($booking['booking_date']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>

    <a href="index.php" style="text-decoration: none; background: #007BFF; color: white; padding: 10px; border-radius: 5px;">Back to Home</a>
</body>
</html>
